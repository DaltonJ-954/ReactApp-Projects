import { Route, Routes } from "react-router";
import LandingPage from "./features/home/components/LandingPage";
import IndexGenres from "./features/genres/components/IndexGenres";
import CreateGenre from "./features/genres/components/CreateGenre";
import EditGenre from "./features/genres/components/EditGenre";
import CreateMovie from "./features/movies/components/CreateMovie";
import EditMovie from "./features/movies/components/EditMovie";
import FilterMovies from "./features/movies/components/FilterMovies";
import MovieDetail from "./features/movies/components/MovieDetail";
import CreateActor from "./features/actors/components/CreateActor";
import EditActor from "./features/actors/components/EditActor";
import IndexActors from "./features/actors/components/IndexActors";
import CreateTheater from "./features/theaters/components/CreateTheater";
import EditTheater from "./features/theaters/components/EditTheater";
import IndexTheaters from "./features/theaters/components/IndexTheaters";
import HandleRouteNotFound from "./features/home/components/HandleRouteNotFound";

export default function AppRoutes() {
    return (
        <Routes>
          <Route path="/" element={<LandingPage />} />

          <Route path="/genres" element={<IndexGenres />} />
          <Route path="/genres/create" element={<CreateGenre />} />
          <Route path="/genres/edit/:id" element={<EditGenre />} />

          <Route path="/actors" element={<IndexActors />} />
          <Route path="/actors/create" element={<CreateActor />} />
          <Route path="/actors/edit/:id" element={<EditActor />} />

          <Route path="/theaters" element={<IndexTheaters />} />
          <Route path="/theaters/create" element={<CreateTheater />} />
          <Route path="/theaters/edit/:id" element={<EditTheater />} />

          <Route path="/movies/filter" element={<FilterMovies />} />
          <Route path="/movies/create" element={<CreateMovie />} />
          <Route path="/movies/edit/:id" element={<EditMovie />} />
          <Route path="/movie" element={<MovieDetail />} />

          <Route path="*" element={<HandleRouteNotFound />} />
        </Routes>
    )
}