export default interface ActorCreation {
    name: string;
    dateOfBirth: string;
    picture?: File;
}