export default interface Genre {
    id: number;
    name: string;
}