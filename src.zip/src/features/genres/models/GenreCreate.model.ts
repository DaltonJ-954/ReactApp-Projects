export default interface GenreCreate {
    name: string;
}