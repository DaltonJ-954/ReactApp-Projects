import { useState, useEffect } from "react";
import MoviesList from "../../movies/components/MoviesList";
import type Movie from "../../movies/models/movie.model";
import type LandingPageDTO from "./LandingPageDTO";

export default function LandingPage() {

    const [movies, setMovies] = useState<LandingPageDTO>({})

  useEffect(() => {
    const inTheaters: Movie[] = [
    {
      id: 1,
      title: "Dune: Part 2",
      poster: "https://image.tmdb.org/t/p/original/5aUVLiqcW0kFTBfGsCWjvLas91w.jpg"
    },
    {
      id: 2,
      title: "Moana 2",
      poster: "https://is1-ssl.mzstatic.com/image/thumb/Music211/v4/6e/af/43/6eaf430b-771d-0872-fdab-2c786a6d8e9d/24UM1IM23328.rgb.jpg/1200x1200bf-60.jpg"
    },
    {
      id: 3,
      title: "Avengers Endgame",
      poster: "https://th.bing.com/th/id/OIP.NPe2_emQ2NnSqxdh6Lw1EwHaK0?w=189&h=277&c=7&r=0&o=7&cb=ucfimg2&dpr=1.5&pid=1.7&rm=3&ucfimg=1"
    },
    {
      id: 4,
      title: "Alien: Romulus",
      poster: "https://posterspy.com/wp-content/uploads/2024/03/Tenth-Poster-Alien-Romulus-Evolution.jpg"
    },
    {
      id: 5,
      title: "Mario: The Movie",
      poster: "https://th.bing.com/th/id/OIP.WjiZcayuXkOX6nXAYtFCtQHaLu?w=189&h=300&c=7&r=0&o=7&cb=ucfimg2&dpr=1.5&pid=1.7&rm=3&ucfimg=1"
    },
    { id: 6,
      title: "The Conjuring 3",
      poster: "https://www.themoviedb.org/t/p/original/lkjOx3VOSi9PBll6UY6OUyQFZYe.jpg"
    },
    {
      id: 7,
      title: "Sonic The Hedgehog 3",
      poster: "https://www.sonicstadium.org/uploads/monthly_2024_11/2024-sonicmovie3-poster5.jpg.7a8efb5588a90806d203a7909807a5bd.jpg"
    },
    { id: 8,
      title: "Oppenheimer",
      poster: "https://www.moviepostersgallery.com/wp-content/uploads/2023/06/Oppenheimer3.jpg"
    },
    {
      id: 9,
      title: "Creed 3",
      poster: "https://mir-s3-cdn-cf.behance.net/project_modules/hd/17ea3e165462993.6407d8cfaf3a0.jpg"
    },
    { id: 10,
      title: "65",
      poster: "https://tse3.mm.bing.net/th/id/OIP.mn89axXN7xTG-miYqWAs3wHaJ8?rs=1&pid=ImgDetMain&o=7&rm=3"
    },
    {
      id: 11,
      title: "We Live In Time",
      poster: "https://m.media-amazon.com/images/M/MV5BYmQwNzRiNmItODc4Ny00Mjk4LThmYWQtNjI5OGU4OGUxMmY0XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg"
    },
    {
      id: 12,
      title: "John Wick 4",
      poster: "https://posterspy.com/wp-content/uploads/2023/02/John-Wick-4-22.jpg"
    },
    {
      id: 13,
      title: "No Hard Feelings",
      poster: "https://image.tmdb.org/t/p/original/eKtuZ2mgnYdBLeaBtIOnGQ4ejML.jpg"
    },
    {
      id: 14,
      title: "Sinners",
      poster: "https://media-cache.cinematerial.com/p/500x/hkavo2sb/sinners-movie-poster.jpg?v=1743958113"
    },
    {
      id: 15,
      title: "Jurassic World: Rebirth",
      poster: "https://image.tmdb.org/t/p/original/q0fGCmjLu42MPlSO9OYWpI5w86I.jpg"
    }
  ]

  const upcomingReleases: Movie[] = [
    {
      id: 16,
      title: "The Mandalorian & Grogu",
      poster: "https://www.starwarsnewsnet.com/wp-content/uploads/2023/02/Mandalorian-S3-character-poster-Din-and-Grogu.jpg"
    },
    {
      id: 17,
      title: "Avatar 3",
      poster: "https://th.bing.com/th/id/OIP.yaSN_Dr11kV53f4EhEk_HQHaLH?w=189&h=284&c=7&r=0&o=7&cb=ucfimg2&dpr=1.5&pid=1.7&rm=3&ucfimg=1"
    },
    {
      id: 18,
      title: "Mercy",
      poster: "https://th.bing.com/th/id/OIP.A2S0GVtERf43ndr8D_et0QHaK-?w=189&h=280&c=7&r=0&o=7&cb=ucfimg2&dpr=1.5&pid=1.7&rm=3&ucfimg=1"
    },
    {
      id: 19,
      title: "Mortal Kombat II: Scorpion",
      poster: "https://scified.com/u/mk-ii-----scorpion-poster-6783371.jpg"
    },
    {
      id: 20,
      title: "The Super Mario Galaxy",
      poster: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/8w1dFQ8Exn3g8Zy5nokkqo87mMB.jpg"
    },
    {
      id: 21,
      title: "SuperGirl",
      poster: "https://image.tmdb.org/t/p/original/niSvU02l2BONH9ivubV6K1a5QiK.jpg"
    },
    {
      id: 22,
      title: "Spider-Man: Brand New Day",
      poster: "https://posterspy.com/wp-content/uploads/2025/09/Spider-Man-Brand-New-Day-Poster-Ver-2.jpg"
    },
    {
      id: 23,
      title: "Return To Silent Hill",
      poster: "https://image.tmdb.org/t/p/original/60FHq2XklzwZPLfbYzoVW1xwO6k.jpg"
    },
    {
      id: 24,
      title: "Michael",
      poster: "https://mir-s3-cdn-cf.behance.net/project_modules/hd/8de85e189545255.65ad4ce8b5537.jpg"
    },
    { id: 25,
      title: "The Odyssey",
      poster: "https://mir-s3-cdn-cf.behance.net/project_modules/hd/dd96c1235124051.68d143b7bdf09.jpg"
    },
    {
      id: 26,
      title: "Hoppers",
      poster: "https://images.cinemaplus.com/hosted/goodrich-quality-theater/coming-soon/kpuKKrEDhUo5j5rayFehlsuNU34ROdW0Z7Hvf57i.jpg"
    },
    {
      id: 27,
      title: "Project Hail Mary Movie",
      poster: "https://image.tmdb.org/t/p/original/tawKDFUp4toBzirxkv6e5KT5ArE.jpg"
    },
    {
      id: 28,
      title: "Greenland 2: Migration",
      poster: "https://mlpnk72yciwc.i.optimole.com/cqhiHLc.IIZS~2ef73/w:auto/h:auto/q:75/https://bleedingcool.com/wp-content/uploads/2025/09/greenland_migration_xlg.jpg"
    },
    {
      id: 29,
      title: "Masters Of The Universe",
      poster: "https://cdn.kinocheck.com/i/yayf62k2u2.jpg"
    },
    {
      id: 30,
      title: "The Death of Robin Hood",
      poster: "https://imgv2-2-f.scribdassets.com/img/document/773740471/original/a872ca860b/1?v=1"
    },
  ]

  setTimeout(() => {
    setMovies({
      InTheaters: inTheaters,
      UpcomingReleases: upcomingReleases
    })
  }, 700);
  }, [])

    return (
        <>
            <h3>In Theaters</h3>
                  <MoviesList movies={movies.InTheaters} />,
            
                  <h3>Upcoming Releases</h3>
                  <MoviesList movies={movies.UpcomingReleases} />
        </>
    )
}