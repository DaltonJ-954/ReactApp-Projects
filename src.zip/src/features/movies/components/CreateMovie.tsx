import type { SubmitHandler } from "react-hook-form"
import type MovieCreation from "../models/MovieCreation.model"
import MovieForm from "./MovieForm";
import type Genre from "../../genres/models/Genre.model";
import type Theater from "../../theaters/models/Theater.model";

export default function CreateMovie() {

    const onSubmit: SubmitHandler<MovieCreation> = async (data) => {
        await new Promise(resolve => setTimeout(resolve, 2000));
        console.log(data)
    }

    const nonSelectedGenres: Genre[] = [{ id: 1, name: 'Action' }, { id: 2, name: 'Sci-Fi' }, { id: 3, name: "Comedy" }, 
        { id: 4, name: "Fantasy" }, { id: 5, name: "Drama" }, { id: 6, name: "Suspense" }, { id: 7, name: 'Horror' }, 
        { id: 8, name: 'Thriller' }, { id: 9, name: 'Romance' }, { id: 10, name: 'Western' }, { id: 11, name: 'Mystery' },
        { id: 12, name: 'Animation' }, { id: 13, name: 'Adventure' }, { id: 14, name: 'Biography' }, { id: 15, name: 'Crime' },
        { id: 16, name: 'Documentary' }, { id: 17, name: 'Family' }, { id: 18, name: 'History' }, { id: 19, name: 'Music' },
        { id: 20, name: 'Musical' }, { id: 21, name: 'War' }, { id: 22, name: 'Sport' }, { id: 23, name: 'Short Film' },
        { id: 24, name: 'Film Noir' }, { id: 25, name: 'Superhero' }
    ]

    const nonSelectedTheaters: Theater[] = [{ id: 1, name: 'Cinamark Bistro', latitude: 0, Longitude: 0 },
        { id: 2, name: 'Reagal Pompano', latitude: 0, Longitude: 0 }, 
        { id: 3, name: 'AMC Dine-In', latitude: 0, Longitude: 0 }, { id: 4, name: 'Regal Broward', latitude: 0, Longitude: 0 },
        { id: 5, name: 'Cinemark Paradise', latitude: 0, Longitude: 0 }, { id: 6, name: 'AMC Coral Square', latitude: 0, Longitude: 0 },
        { id: 7, name: 'Regal South Beach', latitude: 0, Longitude: 0 }, { id: 8, name: 'Cinemark Miami', latitude: 0, Longitude: 0 },
        { id: 9, name: 'AMC Aventura', latitude: 0, Longitude: 0 }, { id: 10, name: 'Regal Doral', latitude: 0, Longitude: 0 },
        { id: 11, name: 'Cinemark Pembroke', latitude: 0, Longitude: 0 }
    ]

    return (
        <>
            <h3>Create Movie</h3>
            <MovieForm onSubmit={ onSubmit } nonSelectedGenres={ nonSelectedGenres } 
            selectedGenres={ [] }
            nonSelectedTheaters={ nonSelectedTheaters }
            selectedTheaters={ [] }
            selectedActors={ [] }
            />
        </>
    )
}