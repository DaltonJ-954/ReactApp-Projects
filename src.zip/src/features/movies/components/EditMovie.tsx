import { useEffect, useState } from "react";
import { useParams } from "react-router"
import type MovieCreation from "../models/MovieCreation.model";
import type { SubmitHandler } from "react-hook-form";
import Loading from "../../../components/Loading";
import MovieForm from "./MovieForm";
import type Genre from "../../genres/models/Genre.model";
import type Theater from "../../theaters/models/Theater.model";

export default function EditMovie() {

    const {id} = useParams();
    const [model, setModel] = useState<MovieCreation | undefined>(undefined);

    useEffect(() => {
        const timerId = setTimeout(() => {
            setModel({ title: 'Mission: Impossible: Dead Reckoning', releaseDate: '12-June-2023', trailer: 'myURL', poster: 'https://posterspy.com/wp-content/uploads/2023/08/last-MI.jpg' })
        }, 1000);

        return () => clearInterval(timerId);
    }, [id])

    const onSubmit: SubmitHandler<MovieCreation> = async (data) => {
            await new Promise(resolve => setTimeout(resolve, 2000));
            console.log(data)
        }

        const nonSelectedGenres: Genre[] = [{ id: 1, name: 'Action' }]
        const selectedGenres: Genre[] = [{ id: 2, name: 'Sci-Fi' }]

        const nonSelectedTheaters: Theater[] = [{ id: 1, name: 'Boca Cinamark', latitude: 0, Longitude: 0} ];
        const selectedTheaters: Theater[] = [ { id: 2, name: 'Reagal Pompano', latitude: 0, Longitude: 0} ];

    return (
        <>
            <h3>Edit Movie</h3>
            { model ? <MovieForm model={model} onSubmit={onSubmit}
            selectedGenres={selectedGenres}
            nonSelectedGenres={nonSelectedGenres}
            selectedTheaters={selectedTheaters}
            nonSelectedTheaters={nonSelectedTheaters} selectedActors={[]}  /> : <Loading /> }
        </>
    )
}