import { Typeahead } from "react-bootstrap-typeahead"
import type MovieActor from "../models/MovieActor.model"
import type { Option } from "react-bootstrap-typeahead/types/types"
import { useState } from "react";

export default function TypeAheadActors(props: TypeAheadActorsProps) {

    const actors: MovieActor[] = [
        { id: 1, name: 'Chris Pratt', character: '', picture: 'https://i.pinimg.com/originals/89/3a/c1/893ac1b31a89071e67cd29d552581e72.jpg'},
        { id: 2, name: 'Rebecca Hall', character: '', picture: 'https://celebmafia.com/wp-content/uploads/2017/04/rebecca-hall-permission-screening-at-tribeca-film-festival-4-22-2017-1.jpg'},
        { id: 3, name: 'Michael Fassbender', character: '', picture: 'https://tse1.mm.bing.net/th/id/OIP.J40DcMeP_P8aG5_vKDRGcgAAAA?rs=1&pid=ImgDetMain&o=7&rm=3'},
        { id: 4, name: 'Michael B. Jordan', character: '', picture: 'https://wwd.com/wp-content/uploads/2022/12/MAB_4946.jpeg'},
        { id: 5, name: 'Brad Pitt', character: '', picture: 'https://m.media-amazon.com/images/I/51pnIZ49+2L.jpg'},
        { id: 6, name: 'Dave Bautista', character: '', picture: 'https://3.bp.blogspot.com/-8u9EL3Hgyjw/VtV8EnMFwMI/AAAAAAACLVk/yGKDLwL18q8/s1600/7.jpg'},
        { id: 7, name: 'Millie Bobby Brown', character: '', picture: 'https://celebmafia.com/wp-content/uploads/2022/08/millie-bobby-brown-photoshoot-may-2022-more-photos-3.jpg'},
        { id: 8, name: 'Vin Deisel', character: '', picture: 'https://oyster.ignimgs.com/mediawiki/apis.ign.com/marvel-studios-cinematic-universe/1/16/Groot_textless.jpg'}
    ]

    const selection: MovieActor[] = [];

    const [draggedElement, setDraggedElement] = useState<MovieActor | undefined>(undefined);

    function handleDraggedStart(actor: MovieActor) {
        setDraggedElement(actor);
    }

    function handleDraggedOver(actor: MovieActor) {
        if (!draggedElement || actor.id === draggedElement.id) return;

        const actors = [...props.actors];
        const fromIndex = actors.findIndex(ca => ca.id === draggedElement.id);
        const toIndex = actors.findIndex(ca => ca.id == actor.id);

        if (fromIndex !== - 1 && toIndex !== - 1) {
            [actors[fromIndex], actors[toIndex]] = [actors[toIndex], actors[fromIndex]];
            props.onAdd(actors);
        }
    }

     return (
        <>
            <label>Actors</label>
            <Typeahead

                onChange={ (actors: Option[]) => {
                    const selectedActor = actors[0] as MovieActor;
                    if (props.actors.findIndex(ca => ca.id === selectedActor.id) === -1) {
                        selectedActor.character = '';
                        props.onAdd([...props.actors, selectedActor]);
                    }
                }}

                options={ actors }
                filterBy={ ['name'] }
                labelKey={ (option: Option) => {
                    const actor = option as MovieActor
                    return actor.name;
                } }
                placeholder="Write the name of the actor..."
                minLength={ 3 }
                selected={ selection }
                flip={ true }
                renderMenuItemChildren={ (option: Option) => {
                    const actor = option as MovieActor;
                    return (
                        <>
                            <img alt="actor's image" src={ actor.picture }
                            style={ { height: '64px', width: '64px', marginRight: '10px'}} 
                            />
                            <span>{ actor. name }</span>
                        </>
                    )
                }}
            />

            <ul className="list-group">
                { props.actors.map(actor => <li
                draggable={ true } 
                onDragStart={ () => handleDraggedStart(actor) }
                onDragOver={ () => handleDraggedOver(actor) }
                key={ actor.id }
                className="lis-group-item d-flex align-items-center"
                >
                    <div style={ { width: '70px'}}>
                        <img alt="picture" style={ { height: '60px'} } src={ actor.picture } />

                    </div>

                    <div style={ { width: '150px', marginLeft: '1rem' }}>
                        { actor.name }
                    </div>

                    <div className="flex-grow -1 mx-3">
                        <input className="form-control" placeholder="Character"
                            value={ actor.character }
                            onChange={ e => props.onCharacterChange(actor.id, e.currentTarget.value) } 
                        />
                    </div>

                    <span role="button"
                    className="badge text-bg-secondary"
                    onClick={ () => props.onRemove(actor) }
                    >
                        X
                    </span>
                </li>)}
            </ul>

        </>
    )
}

interface TypeAheadActorsProps {
    actors: MovieActor[];
    onAdd(actors: MovieActor[]): void;
    onRemove(actor: MovieActor): void;
    onCharacterChange(id: number, character: string): void;
}