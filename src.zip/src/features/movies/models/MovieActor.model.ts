export default interface MovieActor {
    id: number;
    name: string;
    picture: string;
    character: string;
}