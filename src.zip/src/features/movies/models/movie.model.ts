export default interface Movie {
    id: number;
    title: string;
    poster: string;
}