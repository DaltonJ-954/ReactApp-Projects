export default interface TheaterCreation {
    name: string;
    latitude: number;
    longitude: number;
}